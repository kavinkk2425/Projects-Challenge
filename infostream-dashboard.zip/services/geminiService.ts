
import { GoogleGenAI, Type } from "@google/genai";
import { NotificationCategory, Priority } from "../types";

// The API key is obtained directly from process.env.API_KEY during client initialization

export const classifyNotification = async (text: string): Promise<{
  category: NotificationCategory;
  priority: Priority;
  summary: string;
}> => {
  // Fix: Use process.env.API_KEY directly to initialize the client
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following college campus announcement and determine its category, priority, and provide a short summary.
    
    Announcement: "${text}"
    
    Available Categories: Academic, Administrative, Placement, Exam, Events, Emergency, Hostel.
    Available Priorities: Critical, High, Medium, Low.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: {
            type: Type.STRING,
            description: "The primary category of the notification."
          },
          priority: {
            type: Type.STRING,
            description: "The urgency level."
          },
          summary: {
            type: Type.STRING,
            description: "A 10-word summary of the notification."
          }
        },
        required: ["category", "priority", "summary"]
      }
    }
  });

  const result = JSON.parse(response.text);
  
  return {
    category: (Object.values(NotificationCategory).includes(result.category as any) ? result.category : NotificationCategory.ADMINISTRATIVE) as NotificationCategory,
    priority: (Object.values(Priority).includes(result.priority as any) ? result.priority : Priority.LOW) as Priority,
    summary: result.summary
  };
};
