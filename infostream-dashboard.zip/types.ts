
export enum NotificationCategory {
  ACADEMIC = 'Academic',
  ADMINISTRATIVE = 'Administrative',
  PLACEMENT = 'Placement',
  EXAM = 'Exam',
  EVENTS = 'Events',
  EMERGENCY = 'Emergency',
  HOSTEL = 'Hostel'
}

export enum Priority {
  CRITICAL = 'Critical',
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export enum UserRole {
  ADMIN = 'Administrator',
  FACULTY = 'Faculty',
  STUDENT = 'Student'
}

export enum Department {
  COMPUTER_SCIENCE = 'Computer Science',
  MECHANICAL = 'Mechanical',
  ELECTRICAL = 'Electrical',
  CIVIL = 'Civil',
  ALL = 'All Departments'
}

export enum TargetYear {
  FIRST = '1st Year',
  SECOND = '2nd Year',
  THIRD = '3rd Year',
  FOURTH = '4th Year',
  ALL = 'All Years'
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  category: NotificationCategory;
  priority: Priority;
  sender: string;
  timestamp: string;
  targetRoles: UserRole[];
  targetDepartments: Department[];
  targetYears: TargetYear[];
  readCount: number;
  acknowledgedBy: string[]; // User IDs
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  department: Department;
  avatar: string;
}

export interface AnalyticsData {
  category: string;
  count: number;
}
