
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Notification, 
  NotificationCategory, 
  Priority, 
  UserRole, 
  Department,
  TargetYear,
  User
} from './types';
import { CURRENT_USER, MOCK_NOTIFICATIONS, MOCK_FACULTY, FacultyMember } from './constants';
import Sidebar from './components/Sidebar';
import NotificationCard from './components/NotificationCard';
import ComposeNotification from './components/ComposeNotification';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import EventsPage from './components/EventsPage';
import HostelPage from './components/HostelPage';
import PlacementPage from './components/PlacementPage';
import LoginPage from './components/LoginPage';

const STORAGE_KEY = 'infostream_filters';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS);
  
  // Dashboard Context Selection
  const [dashDept, setDashDept] = useState<Department | null>(null);
  const [dashYear, setDashYear] = useState<TargetYear | null>(null);
  const [dashHOD, setDashHOD] = useState<FacultyMember | null>(null);
  const [dashAdvisor, setDashAdvisor] = useState<FacultyMember | null>(null);
  const [isContextLocked, setIsContextLocked] = useState(false);

  // Global Search/Filter (Header)
  const [filterCategory, setFilterCategory] = useState<NotificationCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [senderFilter, setSenderFilter] = useState<string>('All');
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const filterRef = useRef<HTMLDivElement>(null);

  const isAdmin = currentUser?.role === UserRole.ADMIN;

  // Persistence
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.searchQuery) setSearchQuery(parsed.searchQuery);
        if (parsed.filterCategory) setFilterCategory(parsed.filterCategory);
        if (parsed.startDate) setStartDate(parsed.startDate);
        if (parsed.endDate) setEndDate(parsed.endDate);
        if (parsed.senderFilter) setSenderFilter(parsed.senderFilter);
      } catch (e) { console.error(e); }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ searchQuery, filterCategory, startDate, endDate, senderFilter }));
  }, [searchQuery, filterCategory, startDate, endDate, senderFilter]);

  // Unique Senders
  const uniqueSenders = useMemo(() => ['All', ...Array.from(new Set(notifications.map(n => n.sender)))], [notifications]);

  // Faculty Filter
  const availableHODs = useMemo(() => MOCK_FACULTY.filter(f => f.role === 'HOD' && f.dept === dashDept), [dashDept]);
  const availableAdvisors = useMemo(() => MOCK_FACULTY.filter(f => f.role === 'Advisor' && f.dept === dashDept && f.year === dashYear), [dashDept, dashYear]);

  const handleLogin = (user: User) => { setCurrentUser(user); setIsAuthenticated(true); };
  const handleLogout = () => {
    setIsAuthenticated(false); setCurrentUser(null); setCurrentTab('dashboard'); setIsContextLocked(false);
    setDashDept(null); setDashYear(null); setDashHOD(null); setDashAdvisor(null);
  };

  const handleAcknowledge = (id: string) => {
    if (!currentUser) return;
    setNotifications(prev => prev.map(n => n.id === id && !n.acknowledgedBy.includes(currentUser.id) ? { ...n, acknowledgedBy: [...n.acknowledgedBy, currentUser.id] } : n));
  };

  const handleNewNotification = (n: Notification) => { setNotifications(prev => [n, ...prev]); setCurrentTab('notifications'); };
  const resetDashboardContext = () => { setIsContextLocked(false); setDashDept(null); setDashYear(null); setDashHOD(null); setDashAdvisor(null); };
  const activeFilterCount = useMemo(() => [filterCategory !== 'All', !!startDate, !!endDate, senderFilter !== 'All'].filter(Boolean).length, [filterCategory, startDate, endDate, senderFilter]);
  const clearAllFilters = () => { setFilterCategory('All'); setSearchQuery(''); setStartDate(''); setEndDate(''); setSenderFilter('All'); };

  const filteredNotifications = useMemo(() => {
    if (!currentUser) return [];
    return notifications.filter(n => {
      const matchesSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase()) || n.message.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'All' || n.category === filterCategory;
      const matchesSender = senderFilter === 'All' || n.sender === senderFilter;
      const nDate = new Date(n.timestamp);
      const matchesStartDate = !startDate || nDate >= new Date(startDate);
      const matchesEndDate = !endDate || nDate <= new Date(endDate + 'T23:59:59');
      const matchesDashDept = !isContextLocked || !dashDept || n.targetDepartments.includes(dashDept) || n.targetDepartments.includes(Department.ALL);
      const matchesDashYear = !isContextLocked || !dashYear || n.targetYears.includes(dashYear) || n.targetYears.includes(TargetYear.ALL);
      const isRelevant = n.targetRoles.includes(currentUser.role) && (n.targetDepartments.includes(Department.ALL) || n.targetDepartments.includes(currentUser.department));
      return matchesSearch && matchesCategory && matchesSender && matchesStartDate && matchesEndDate && (isAdmin || isRelevant) && matchesDashDept && matchesDashYear;
    });
  }, [notifications, searchQuery, filterCategory, senderFilter, startDate, endDate, isContextLocked, dashDept, dashYear, currentUser]);

  // Grouping logic for organized feed
  const groupedNotifications = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const groups: { [key: string]: Notification[] } = {
      'Today': [],
      'Yesterday': [],
      'Earlier': []
    };

    filteredNotifications.forEach(n => {
      const nDate = new Date(n.timestamp);
      nDate.setHours(0, 0, 0, 0);
      if (nDate.getTime() === today.getTime()) groups['Today'].push(n);
      else if (nDate.getTime() === yesterday.getTime()) groups['Yesterday'].push(n);
      else groups['Earlier'].push(n);
    });

    return groups;
  }, [filteredNotifications]);

  if (!isAuthenticated || !currentUser) return <LoginPage onLogin={handleLogin} />;

  return (
    <div className={`flex min-h-screen bg-[#050505] text-slate-300 font-sans ${isAdmin ? 'admin-theme' : ''}`}>
      <Sidebar 
        currentTab={currentTab} 
        setCurrentTab={(tab) => { setCurrentTab(tab); setIsSidebarOpen(false); }} 
        userRole={currentUser.role} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onLogout={handleLogout}
      />

      <main className="flex-1 flex flex-col overflow-hidden w-full relative">
        <header className="bg-[#050505]/80 backdrop-blur-xl border-b border-[#1a1a1c] h-20 px-4 md:px-12 flex items-center justify-between sticky top-0 z-50 shrink-0">
          <div className="flex items-center gap-4 md:gap-8 flex-1 h-full">
            <button onClick={() => setIsSidebarOpen(true)} className="md:hidden p-2 text-slate-500 hover:bg-[#121214] rounded-xl transition-colors">
              <i className="fa-solid fa-bars-staggered text-xl"></i>
            </button>
            <div className="relative w-full max-w-lg flex items-center" ref={filterRef}>
              <i className="fa-solid fa-magnifying-glass absolute left-4 text-slate-600 text-xs"></i>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isAdmin ? "Search institutional logs..." : "Search for updates..."}
                className="w-full bg-[#0d0d0e] text-[13px] font-medium text-white border border-[#1f1f22] rounded-2xl py-3 pl-11 pr-14 focus:ring-4 focus:ring-[#10b981]/5 outline-none transition-all placeholder:text-slate-700"
              />
              <button onClick={() => setIsFilterOpen(!isFilterOpen)} className={`absolute right-2 p-2 rounded-xl flex items-center gap-2 ${activeFilterCount > 0 ? 'bg-[#10b981]/20 text-[#10b981]' : 'text-slate-600 hover:text-white'}`}>
                <i className="fa-solid fa-sliders text-xs"></i>
                {activeFilterCount > 0 && <span className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black bg-[#10b981] text-black">{activeFilterCount}</span>}
              </button>
              {isFilterOpen && (
                <div className="absolute top-[calc(100%+10px)] left-0 right-0 bg-[#0d0d0e] border border-[#1f1f22] rounded-[2rem] shadow-2xl p-8 z-[100] animate-in fade-in zoom-in-95 duration-200">
                   <div className="flex items-center justify-between mb-8">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Signal Configuration</p>
                      <button onClick={clearAllFilters} className="text-[9px] font-black text-red-500 uppercase tracking-widest">Clear Protocol</button>
                   </div>
                   <div className="space-y-6">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {['All', ...Object.values(NotificationCategory)].map(cat => (
                          <button key={cat} onClick={() => setFilterCategory(cat as any)} className={`px-4 py-2 rounded-xl text-[10px] font-bold border transition-all ${filterCategory === cat ? 'bg-white text-black border-white' : 'bg-[#050505] text-slate-500 border-[#1f1f22]'}`}>{cat}</button>
                        ))}
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full bg-[#050505] border border-[#1f1f22] rounded-xl p-3 text-xs font-bold text-white outline-none [color-scheme:dark]" />
                        <select value={senderFilter} onChange={(e) => setSenderFilter(e.target.value)} className="w-full bg-[#050505] border border-[#1f1f22] rounded-xl p-3 text-xs font-bold text-white outline-none">
                          {uniqueSenders.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                   </div>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4 md:pl-8 border-l border-[#1a1a1c] h-10 ml-4">
             <div className="text-right hidden md:block">
                <p className="text-[13px] font-bold text-white">{currentUser.name}</p>
                <p className="text-[9px] font-black text-[#10b981] uppercase tracking-[0.2em]">{currentUser.role}</p>
             </div>
             <img src={currentUser.avatar} alt="P" className="w-10 h-10 rounded-[12px] bg-[#0d0d0e] border border-[#1f1f22]" />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#050505]">
          <div className="max-w-7xl mx-auto p-4 md:p-12">
            {currentTab === 'dashboard' && (
              <div className="h-full">
                {!isContextLocked ? (
                  /* STEP 1: CONTEXT */
                  <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-12 animate-in fade-in zoom-in duration-700">
                    <div className="text-center space-y-4">
                      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#10b981]/10 border border-[#10b981]/20 text-[#10b981]">
                        <i className="fa-solid fa-fingerprint text-[10px]"></i>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em]">Institutional Verification</span>
                      </div>
                      <h2 className="text-5xl font-black text-white tracking-tighter">Define <span className="text-slate-600">Access Point</span></h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-5xl">
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-slate-600 uppercase tracking-widest ml-2">Department</label>
                        <select value={dashDept || ''} onChange={(e) => setDashDept(e.target.value as Department)} className="w-full bg-[#0d0d0e] border border-[#1f1f22] rounded-2xl p-4 text-xs font-bold text-white outline-none cursor-pointer">
                          <option value="" disabled>Select Dept</option>
                          {Object.values(Department).filter(d => d !== Department.ALL).map(d => <option key={d} value={d}>{d}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-slate-600 uppercase tracking-widest ml-2">Year Node</label>
                        <select value={dashYear || ''} onChange={(e) => setDashYear(e.target.value as TargetYear)} className="w-full bg-[#0d0d0e] border border-[#1f1f22] rounded-2xl p-4 text-xs font-bold text-white outline-none cursor-pointer">
                          <option value="" disabled>Select Year</option>
                          {Object.values(TargetYear).filter(y => y !== TargetYear.ALL).map(y => <option key={y} value={y}>{y}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-slate-600 uppercase tracking-widest ml-2">H.O.D Context</label>
                        <select value={dashHOD?.id || ''} onChange={(e) => setDashHOD(availableHODs.find(f => f.id === e.target.value) || null)} disabled={!dashDept} className="w-full bg-[#0d0d0e] border border-[#1f1f22] rounded-2xl p-4 text-xs font-bold text-white outline-none cursor-pointer disabled:opacity-30">
                          <option value="" disabled>Select HOD</option>
                          {availableHODs.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[9px] font-black text-slate-600 uppercase tracking-widest ml-2">Class Advisor</label>
                        <select value={dashAdvisor?.id || ''} onChange={(e) => setDashAdvisor(availableAdvisors.find(f => f.id === e.target.value) || null)} disabled={!dashYear} className="w-full bg-[#0d0d0e] border border-[#1f1f22] rounded-2xl p-4 text-xs font-bold text-white outline-none cursor-pointer disabled:opacity-30">
                          <option value="" disabled>Select Advisor</option>
                          {availableAdvisors.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                      </div>
                    </div>
                    <button disabled={!dashDept || !dashYear || !dashHOD || !dashAdvisor} onClick={() => setIsContextLocked(true)} className="px-16 py-5 bg-white text-black rounded-full font-black uppercase tracking-[0.4em] text-[10px] shadow-2xl transition-all disabled:opacity-20 hover:scale-105 active:scale-95">Establish Hub Connection</button>
                  </div>
                ) : (
                  /* STEP 2: HUB */
                  <div className="space-y-10 animate-in slide-in-from-bottom-10 duration-700">
                    <div className="flex justify-between items-end border-b border-[#1a1a1c] pb-8">
                       <div className="space-y-2">
                          <button onClick={resetDashboardContext} className="text-[9px] font-black text-slate-600 hover:text-white uppercase tracking-widest mb-3 block"><i className="fa-solid fa-rotate-left mr-2"></i> Reset Operational Proto</button>
                          <h2 className="text-4xl font-black text-white tracking-tighter">{dashDept} <span className="text-slate-800">/</span> {dashYear}</h2>
                       </div>
                       {isAdmin && <button onClick={() => setCurrentTab('compose')} className="px-6 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-indigo-500/10">Inject Signal</button>}
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                       <div className="bg-[#0d0d0e] border border-[#1a1a1c] p-6 rounded-3xl flex items-center gap-5">
                          <img src={dashHOD?.avatar} className="w-14 h-14 rounded-2xl bg-black border border-[#1f1f22]" alt="" />
                          <div>
                            <p className="text-[9px] font-black text-[#10b981] uppercase tracking-widest mb-1">H.O.D Node</p>
                            <h4 className="text-md font-black text-white">{dashHOD?.name}</h4>
                          </div>
                       </div>
                       <div className="bg-[#0d0d0e] border border-[#1a1a1c] p-6 rounded-3xl flex items-center gap-5">
                          <img src={dashAdvisor?.avatar} className="w-14 h-14 rounded-2xl bg-black border border-[#1f1f22]" alt="" />
                          <div>
                            <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest mb-1">Advisor Node</p>
                            <h4 className="text-md font-black text-white">{dashAdvisor?.name}</h4>
                          </div>
                       </div>
                       <div className="bg-gradient-to-br from-[#121214] to-black border border-[#1a1a1c] p-6 rounded-3xl">
                          <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-3">Live Stats</p>
                          <div className="flex justify-between font-black text-white">
                             <div className="text-center"><p className="text-xl">64</p><p className="text-[8px] text-slate-500">PEERS</p></div>
                             <div className="text-center"><p className="text-xl text-emerald-500">89%</p><p className="text-[8px] text-slate-500">ATTENDANCE</p></div>
                             <div className="text-center"><p className="text-xl text-[#10b981]">12</p><p className="text-[8px] text-slate-500">SIGNALS</p></div>
                          </div>
                       </div>
                    </div>
                    <div className="space-y-6">
                       <h3 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-3"><i className="fa-solid fa-tower-broadcast text-[#10b981]"></i> Recent Injections</h3>
                       <div className="space-y-4">
                          {filteredNotifications.length > 0 ? (
                            filteredNotifications.map(n => <NotificationCard key={n.id} notification={n} onAcknowledge={isAdmin ? undefined : handleAcknowledge} hasAcknowledged={n.acknowledgedBy.includes(currentUser.id)} />)
                          ) : (
                            <div className="py-20 text-center bg-[#0d0d0e] border border-dashed border-[#1a1a1c] rounded-[3rem] text-slate-700 font-bold uppercase text-[10px] tracking-widest">Quiet on the network.</div>
                          )}
                       </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {currentTab === 'notifications' && (
              <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in duration-500">
                 {/* Organised Header with Pulse Stats */}
                 <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                    <div className="space-y-2">
                       <h2 className="text-5xl font-black text-white tracking-tighter uppercase">Institutional <span className="text-slate-700">Stream</span></h2>
                       <p className="text-[#10b981] text-[10px] font-black uppercase tracking-[0.5em]">Synchronized Global Signal Protocol</p>
                    </div>
                    <div className="flex items-center gap-4 bg-[#0d0d0e] p-4 rounded-3xl border border-[#1a1a1c]">
                       <div className="text-center px-4 border-r border-[#1f1f22]">
                          <p className="text-xl font-black text-white leading-none">{filteredNotifications.length}</p>
                          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-1">Signals</p>
                       </div>
                       <div className="text-center px-4 border-r border-[#1f1f22]">
                          <p className="text-xl font-black text-red-500 leading-none">{filteredNotifications.filter(n => n.priority === Priority.CRITICAL).length}</p>
                          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-1">Breaches</p>
                       </div>
                       <div className="text-center px-4">
                          <p className="text-xl font-black text-indigo-400 leading-none">99%</p>
                          <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-1">Uptime</p>
                       </div>
                    </div>
                 </div>

                 {/* The Organised Timeline Stream */}
                 <div className="relative pl-8 md:pl-12">
                    {/* Visual Vertical Path */}
                    <div className="absolute left-[3px] md:left-[5px] top-0 bottom-0 w-[2px] bg-gradient-to-b from-[#10b981] via-indigo-500 to-transparent opacity-20"></div>

                    <div className="space-y-16">
                      {Object.entries(groupedNotifications).map(([group, list]) => list.length > 0 && (
                        <div key={group} className="space-y-8 relative">
                           {/* Sticky Date/Group Header */}
                           <div className="sticky top-20 z-30 bg-[#050505]/60 backdrop-blur-md py-4 -ml-8 md:-ml-12 pl-8 md:pl-12">
                              <div className="flex items-center gap-4">
                                 <div className={`w-3 h-3 rounded-full border-2 ${group === 'Today' ? 'bg-[#10b981] border-[#10b981]/20 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-slate-800 border-slate-700'} absolute left-[2px] md:left-[4px]`}></div>
                                 <h3 className="text-xs font-black text-white uppercase tracking-[0.4em] flex items-center gap-3">
                                    {group === 'Today' ? 'Live Signal' : group === 'Yesterday' ? 'Recent Transmissions' : 'Archived Logs'}
                                    <span className="h-[1px] w-20 bg-[#1a1a1c]"></span>
                                 </h3>
                              </div>
                           </div>

                           <div className="space-y-4">
                              {list.map(n => (
                                <div key={n.id} className="relative group/signal">
                                   {/* Signal Node Dot */}
                                   <div className="absolute -left-[30px] md:-left-[43px] top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-slate-800 border border-slate-700 group-hover/signal:bg-white transition-all z-20"></div>
                                   <NotificationCard 
                                     notification={n} 
                                     onAcknowledge={isAdmin ? undefined : handleAcknowledge} 
                                     hasAcknowledged={n.acknowledgedBy.includes(currentUser.id)} 
                                   />
                                </div>
                              ))}
                           </div>
                        </div>
                      ))}

                      {filteredNotifications.length === 0 && (
                        <div className="py-32 text-center bg-[#0d0d0e] border border-dashed border-[#1a1a1c] rounded-[3rem] animate-pulse">
                          <i className="fa-solid fa-satellite text-4xl text-slate-800 mb-6 block"></i>
                          <p className="text-slate-600 font-bold uppercase text-[10px] tracking-widest leading-relaxed">
                             Zero Signals Detected on this Frequency.<br/>
                             <span className="text-slate-800">Adjust Node Parameters to Retry.</span>
                          </p>
                          {activeFilterCount > 0 && (
                            <button onClick={clearAllFilters} className="mt-8 px-8 py-3 bg-[#10b981]/10 border border-[#10b981]/20 text-[#10b981] rounded-xl text-[9px] font-black uppercase tracking-widest">Reset Global Protocol</button>
                          )}
                        </div>
                      )}
                    </div>
                 </div>
              </div>
            )}

            {currentTab === 'events' && <EventsPage />}
            {currentTab === 'hostel' && <HostelPage />}
            {currentTab === 'placement' && <PlacementPage />}
            {currentTab === 'compose' && <ComposeNotification onSend={handleNewNotification} />}
            {currentTab === 'analytics' && <AnalyticsDashboard notifications={notifications} />}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
