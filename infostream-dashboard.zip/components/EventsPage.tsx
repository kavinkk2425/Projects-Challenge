
import React from 'react';
import { MOCK_EVENTS, CampusEvent } from '../constants';

const EventsPage: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Campus Events</h2>
          <p className="text-slate-500 dark:text-slate-400">Discover upcoming symposiums, hackathons, and contests.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-200 dark:shadow-none hover:bg-indigo-700 transition-all">
            Calendar View
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_EVENTS.map((event) => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>
    </div>
  );
};

const EventCard: React.FC<{ event: CampusEvent }> = ({ event }) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Symposium': return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400';
      case 'Hackathon': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400';
      case 'Coding Contest': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
      default: return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400';
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm border border-slate-100 dark:border-slate-700 transition-all hover:shadow-xl group">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={event.image} 
          alt={event.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-sm ${getTypeColor(event.type)}`}>
            {event.type}
          </span>
        </div>
        {event.prizePool && (
          <div className="absolute bottom-4 right-4 bg-amber-500 text-white px-3 py-1 rounded-lg text-xs font-bold shadow-lg">
            <i className="fa-solid fa-trophy mr-1"></i> {event.prizePool}
          </div>
        )}
      </div>
      
      <div className="p-6 space-y-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
            {event.title}
          </h3>
          <div className="flex items-center gap-4 mt-2 text-xs text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1">
              <i className="fa-regular fa-calendar text-indigo-500"></i>
              {event.date}
            </span>
            <span className="flex items-center gap-1">
              <i className="fa-solid fa-location-dot text-red-500"></i>
              {event.venue}
            </span>
          </div>
        </div>

        <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
          {event.description}
        </p>

        <div className="pt-4 border-t border-slate-50 dark:border-slate-700/50 flex items-center justify-between">
          <div className="text-[10px] text-slate-400">
            <p className="font-semibold text-slate-500 dark:text-slate-400">Coordinator</p>
            <p>{event.coordinator}</p>
          </div>
          <button className="px-4 py-1.5 bg-slate-900 dark:bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-slate-800 dark:hover:bg-indigo-700 transition-all">
            Join Event
          </button>
        </div>
      </div>
    </div>
  );
};

export default EventsPage;
