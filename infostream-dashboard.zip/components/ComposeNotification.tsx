
import React, { useState } from 'react';
import { NotificationCategory, Priority, UserRole, Department, TargetYear, Notification } from '../types';
import { CATEGORY_COLORS } from '../constants';
import { classifyNotification } from '../services/geminiService';

interface ComposeNotificationProps {
  onSend: (notification: Notification) => void;
}

const ComposeNotification: React.FC<ComposeNotificationProps> = ({ onSend }) => {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState<NotificationCategory>(NotificationCategory.ADMINISTRATIVE);
  const [priority, setPriority] = useState<Priority>(Priority.MEDIUM);
  const [selectedRoles, setSelectedRoles] = useState<UserRole[]>([UserRole.STUDENT, UserRole.FACULTY]);
  const [selectedDepts, setSelectedDepts] = useState<Department[]>([Department.ALL]);
  const [selectedYears, setSelectedYears] = useState<TargetYear[]>([TargetYear.ALL]);
  const [isClassifying, setIsClassifying] = useState(false);

  const handleAIClassify = async () => {
    if (!message) return alert("Please enter a message first.");
    setIsClassifying(true);
    try {
      const result = await classifyNotification(`${title}: ${message}`);
      setCategory(result.category);
      setPriority(result.priority);
    } catch (error) {
      console.error("AI Classification failed", error);
    } finally {
      setIsClassifying(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newNotification: Notification = {
      id: Math.random().toString(36).substr(2, 9),
      title,
      message,
      category,
      priority,
      sender: 'Admin Center',
      timestamp: new Date().toISOString(),
      targetRoles: selectedRoles,
      targetDepartments: selectedDepts,
      targetYears: selectedYears,
      readCount: 0,
      acknowledgedBy: []
    };
    onSend(newNotification);
    setTitle('');
    setMessage('');
    alert("Notification Disseminated Successfully!");
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden transition-colors duration-300">
      <div className="bg-slate-50 dark:bg-slate-900/50 p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Broadcast Center</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Targeted institutional communication.</p>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-xs font-bold border ${CATEGORY_COLORS[category]} shadow-sm transition-all animate-in fade-in zoom-in`}>
          Selected: {category}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-3">Notice Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-medium"
                placeholder="e.g. Annual Sports Meet 2024"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-3">
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300">Content</label>
                <button
                  type="button"
                  onClick={handleAIClassify}
                  disabled={isClassifying || !message}
                  className="text-xs bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 px-4 py-1.5 rounded-full font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900/40 flex items-center gap-2 transition-all disabled:opacity-50 border border-indigo-100 dark:border-indigo-800"
                >
                  <i className={`fa-solid ${isClassifying ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'}`}></i>
                  {isClassifying ? 'Analyzing Context...' : 'AI Categorize'}
                </button>
              </div>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                rows={6}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none text-sm leading-relaxed"
                placeholder="Enter the full message details here..."
              ></textarea>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-4">Select Category</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {Object.values(NotificationCategory).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={`px-3 py-3 rounded-xl text-[11px] font-bold transition-all border text-center flex flex-col items-center gap-1.5 group ${
                      category === c
                        ? `${CATEGORY_COLORS[c]} ring-2 ring-offset-2 dark:ring-offset-slate-800 ring-indigo-500 scale-[1.02] shadow-sm`
                        : 'bg-white dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-100 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500'
                    }`}
                  >
                    <i className={`fa-solid ${
                      c === NotificationCategory.ACADEMIC ? 'fa-graduation-cap' :
                      c === NotificationCategory.ADMINISTRATIVE ? 'fa-building-columns' :
                      c === NotificationCategory.PLACEMENT ? 'fa-briefcase' :
                      c === NotificationCategory.EXAM ? 'fa-file-signature' :
                      c === NotificationCategory.EVENTS ? 'fa-calendar-star' :
                      c === NotificationCategory.EMERGENCY ? 'fa-circle-exclamation' :
                      'fa-bed'
                    } text-sm ${category === c ? '' : 'text-slate-400 group-hover:text-slate-600'}`}></i>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
               <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Urgency</label>
                  <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl">
                    {Object.values(Priority).map(p => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setPriority(p)}
                        className={`flex-1 py-2 text-[10px] font-bold rounded-lg transition-all ${
                          priority === p 
                            ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' 
                            : 'text-slate-500 hover:text-slate-700'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
               </div>

               <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Target Years</label>
                  <div className="flex flex-wrap gap-2">
                    {Object.values(TargetYear).map((year) => (
                      <button
                        key={year}
                        type="button"
                        onClick={() => {
                          if (selectedYears.includes(year)) {
                            setSelectedYears(selectedYears.filter(y => y !== year));
                          } else {
                            setSelectedYears([...selectedYears, year]);
                          }
                        }}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                          selectedYears.includes(year)
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                            : 'bg-white dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-100 dark:border-slate-600'
                        }`}
                      >
                        {year}
                      </button>
                    ))}
                  </div>
               </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Target Departments</label>
              <div className="flex flex-wrap gap-2">
                {Object.values(Department).map((dept) => (
                  <button
                    key={dept}
                    type="button"
                    onClick={() => {
                      if (selectedDepts.includes(dept)) {
                        setSelectedDepts(selectedDepts.filter(d => d !== dept));
                      } else {
                        setSelectedDepts([...selectedDepts, dept]);
                      }
                    }}
                    className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                      selectedDepts.includes(dept)
                        ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                        : 'bg-white dark:bg-slate-700 text-slate-500 dark:text-slate-400 border-slate-100 dark:border-slate-600'
                    }`}
                  >
                    {dept}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-8 border-t border-slate-100 dark:border-slate-700">
          <button
            type="submit"
            className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 dark:shadow-none hover:bg-indigo-700 transition-all flex items-center gap-3 transform active:scale-95"
          >
            <i className="fa-solid fa-paper-plane"></i>
            Broadcast to Campus
          </button>
        </div>
      </form>
    </div>
  );
};

export default ComposeNotification;
