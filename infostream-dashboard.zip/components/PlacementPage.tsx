
import React from 'react';
import { MOCK_COMPANIES, MOCK_NOTIFICATIONS } from '../constants';
import { NotificationCategory } from '../types';
import NotificationCard from './NotificationCard';

const PlacementPage: React.FC = () => {
  const placementNotifications = MOCK_NOTIFICATIONS.filter(n => n.category === NotificationCategory.PLACEMENT);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Placement Hub</h2>
          <p className="text-slate-500 dark:text-slate-400">Track recruitment drives, statistics, and training modules.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-200 dark:shadow-none hover:bg-indigo-700 transition-all flex items-center gap-2">
            <i className="fa-solid fa-cloud-arrow-up"></i>
            Upload Resume
          </button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Highest Package', value: '45 LPA', icon: 'fa-money-bill-trend-up', color: 'text-emerald-500' },
          { label: 'Avg. Package', value: '9.2 LPA', icon: 'fa-chart-simple', color: 'text-indigo-500' },
          { label: 'Companies Visited', value: '120+', icon: 'fa-building', color: 'text-purple-500' },
          { label: 'Students Placed', value: '85%', icon: 'fa-user-graduate', color: 'text-blue-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-700 flex items-center justify-center ${stat.color}`}>
                <i className={`fa-solid ${stat.icon}`}></i>
              </div>
              <span className="text-xs font-bold text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-1 rounded-lg">+12%</span>
            </div>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Active Drives */}
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <i className="fa-solid fa-briefcase text-indigo-500"></i>
            Current Hiring Drives
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MOCK_COMPANIES.map((company) => (
              <div key={company.id} className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm group hover:border-indigo-500 dark:hover:border-indigo-400 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="h-10 w-24 flex items-center justify-center bg-slate-50 dark:bg-slate-100 p-2 rounded-lg grayscale group-hover:grayscale-0 transition-all">
                    <img src={company.logo} alt={company.name} className="max-h-full max-w-full object-contain" />
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider ${
                    company.status === 'Open' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30' : 
                    company.status === 'Ongoing' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30' : 
                    'bg-slate-100 text-slate-500 dark:bg-slate-700'
                  }`}>
                    {company.status}
                  </span>
                </div>
                <h4 className="font-bold text-slate-800 dark:text-slate-100">{company.role}</h4>
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-1">
                    <i className="fa-solid fa-indian-rupee-sign text-indigo-500"></i>
                    <span>{company.ctc}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <i className="fa-regular fa-clock text-indigo-500"></i>
                    <span>Due: {company.deadline}</span>
                  </div>
                </div>
                <button className="w-full mt-4 py-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-xl text-xs font-bold hover:bg-indigo-600 hover:text-white dark:hover:bg-indigo-600 transition-all">
                  View Details
                </button>
              </div>
            ))}
          </div>

          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 pt-4">
            <i className="fa-solid fa-bullhorn text-purple-500"></i>
            Recruitment News
          </h3>
          <div className="space-y-4">
            {placementNotifications.map(n => (
              <NotificationCard key={n.id} notification={n} />
            ))}
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700">
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <i className="fa-solid fa-graduation-cap text-indigo-500"></i>
              Training Modules
            </h3>
            <div className="space-y-3">
              {[
                { title: 'Aptitude & Logical Reasoning', progress: '65%' },
                { title: 'Data Structures Mastery', progress: '40%' },
                { title: 'Mock Interview Prep', progress: '10%' },
                { title: 'Resume Building Workshop', progress: 'Completed' },
              ].map((module, i) => (
                <div key={i} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{module.title}</span>
                    <span className="text-[10px] text-indigo-500 font-bold">{module.progress}</span>
                  </div>
                  {module.progress !== 'Completed' && (
                    <div className="w-full h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="bg-indigo-500 h-full" style={{ width: module.progress }}></div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl p-6 text-white">
            <h3 className="font-bold text-lg mb-2">TPO Helpdesk</h3>
            <p className="text-sm text-indigo-100 mb-6">Need assistance with the placement portal or drive registrations?</p>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <i className="fa-solid fa-envelope text-xs"></i>
                </div>
                <span className="text-xs">tpo@gce.edu.in</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <i className="fa-solid fa-phone text-xs"></i>
                </div>
                <span className="text-xs">+91 98765 43210</span>
              </div>
            </div>
            <button className="w-full mt-6 py-2 bg-white text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-50 transition-all">
              Book Appointment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlacementPage;
