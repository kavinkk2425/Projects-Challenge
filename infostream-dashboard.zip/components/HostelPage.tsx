
import React, { useState, useMemo } from 'react';
import { MOCK_NOTIFICATIONS } from '../constants';
import { NotificationCategory } from '../types';
import NotificationCard from './NotificationCard';

const HostelPage: React.FC = () => {
  const [selectedHostel, setSelectedHostel] = useState<'Boys' | 'Girls'>('Boys');
  const [unlockedHostels, setUnlockedHostels] = useState<string[]>([]);
  const [accessId, setAccessId] = useState('');
  const [accessKey, setAccessKey] = useState('');
  const [error, setError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const isCurrentUnlocked = unlockedHostels.includes(selectedHostel);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setError('');

    // Mock verification logic
    setTimeout(() => {
      const isValid = 
        (selectedHostel === 'Boys' && accessId === 'boys123' && accessKey === 'pass123') ||
        (selectedHostel === 'Girls' && accessId === 'girls123' && accessKey === 'pass123');

      if (isValid) {
        setUnlockedHostels([...unlockedHostels, selectedHostel]);
        setAccessId('');
        setAccessKey('');
      } else {
        setError('Verification Failed: Invalid Access Node Credentials.');
      }
      setIsVerifying(false);
    }, 800);
  };

  const hostelNotifications = useMemo(() => {
    return MOCK_NOTIFICATIONS.filter(n => {
      if (n.category !== NotificationCategory.HOSTEL) return false;
      const title = n.title.toLowerCase();
      if (selectedHostel === 'Boys' && title.includes('girls')) return false;
      if (selectedHostel === 'Girls' && title.includes('boys')) return false;
      return true;
    });
  }, [selectedHostel]);

  const hostelDetails = {
    Boys: {
      warden: 'Dr. R. Subramanian',
      rooms: '420',
      occupancy: '98%',
      blocks: ['Block A', 'Block B', 'Main Block'],
      amenities: ['Gym', 'Recreation Hall', 'Basketball Court'],
      color: 'indigo',
      glow: 'shadow-indigo-500/10'
    },
    Girls: {
      warden: 'Dr. Meera Krishnan',
      rooms: '380',
      occupancy: '95%',
      blocks: ['Block C', 'Block D', 'Annex'],
      amenities: ['Reading Room', 'Indoor Sports', 'Yoga Hall'],
      color: 'purple',
      glow: 'shadow-purple-500/10'
    }
  };

  const currentDetails = hostelDetails[selectedHostel];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Residence Management</h2>
          <p className="text-slate-500 text-sm">Campus residence status and service updates.</p>
        </div>
        <div className="flex bg-[#0d0d0e] p-1.5 rounded-2xl border border-[#1f1f22] shadow-xl">
          <button
            onClick={() => { setSelectedHostel('Boys'); setError(''); }}
            className={`px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
              selectedHostel === 'Boys'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Boys Hostel
          </button>
          <button
            onClick={() => { setSelectedHostel('Girls'); setError(''); }}
            className={`px-8 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
              selectedHostel === 'Girls'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            Girls Hostel
          </button>
        </div>
      </div>

      {!isCurrentUnlocked ? (
        /* VERIFICATION GATEWAY */
        <div className="max-w-md mx-auto py-20 animate-in zoom-in-95 duration-500">
          <div className={`bg-[#0d0d0e] border border-[#1a1a1c] rounded-[2.5rem] p-10 shadow-2xl relative overflow-hidden`}>
            <div className={`absolute top-0 left-0 w-full h-1 ${selectedHostel === 'Boys' ? 'bg-indigo-600' : 'bg-purple-600'}`}></div>
            
            <div className="text-center mb-8">
              <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-6 border border-[#1f1f22] ${selectedHostel === 'Boys' ? 'text-indigo-400 bg-indigo-400/5' : 'text-purple-400 bg-purple-400/5'}`}>
                <i className={`fa-solid ${selectedHostel === 'Boys' ? 'fa-user-shield' : 'fa-user-lock'} text-2xl`}></i>
              </div>
              <h3 className="text-xl font-black text-white uppercase tracking-tight mb-2">{selectedHostel} Access Key</h3>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em]">Institutional Verification Required</p>
            </div>

            <form onSubmit={handleVerify} className="space-y-5">
              <div className="space-y-2">
                <label className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] ml-1">Node ID</label>
                <input
                  type="text"
                  value={accessId}
                  onChange={(e) => setAccessId(e.target.value)}
                  placeholder={`e.g. ${selectedHostel.toLowerCase()}123`}
                  className="w-full px-5 py-4 bg-[#050505] border border-[#1f1f22] rounded-2xl text-white font-bold text-xs outline-none focus:border-slate-700 transition-all placeholder:text-slate-800"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] ml-1">Protocol Key</label>
                <input
                  type="password"
                  value={accessKey}
                  onChange={(e) => setAccessKey(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-5 py-4 bg-[#050505] border border-[#1f1f22] rounded-2xl text-white font-bold text-xs outline-none focus:border-slate-700 transition-all placeholder:text-slate-800"
                  required
                />
              </div>

              {error && (
                <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-2xl text-[10px] font-bold text-red-500 animate-pulse">
                  <i className="fa-solid fa-triangle-exclamation mr-2"></i>
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isVerifying}
                className={`w-full py-4 rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] transition-all flex items-center justify-center gap-3 ${
                  selectedHostel === 'Boys' 
                  ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xl shadow-indigo-500/10' 
                  : 'bg-purple-600 hover:bg-purple-500 text-white shadow-xl shadow-purple-500/10'
                }`}
              >
                {isVerifying ? <i className="fa-solid fa-spinner fa-spin"></i> : 'Authorize Access'}
              </button>
            </form>
            
            <p className="mt-8 text-[8px] text-slate-800 text-center font-black uppercase tracking-widest leading-relaxed">
              Standard Credentials: {selectedHostel.toLowerCase()}123 / pass123<br/>
              Access attempts are logged by InfoStream security nodes.
            </p>
          </div>
        </div>
      ) : (
        /* UNLOCKED CONTENT */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in slide-in-from-bottom-8 duration-700">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-[#0d0d0e] p-5 rounded-3xl border border-[#1a1a1c] shadow-sm">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Chief Warden</p>
                <p className="text-[13px] font-bold text-white truncate">{currentDetails.warden}</p>
              </div>
              <div className="bg-[#0d0d0e] p-5 rounded-3xl border border-[#1a1a1c] shadow-sm">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Total Rooms</p>
                <p className="text-[13px] font-bold text-white">{currentDetails.rooms}</p>
              </div>
              <div className="bg-[#0d0d0e] p-5 rounded-3xl border border-[#1a1a1c] shadow-sm">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Occupancy</p>
                <p className="text-[13px] font-bold text-emerald-500">{currentDetails.occupancy}</p>
              </div>
              <div className="bg-[#0d0d0e] p-5 rounded-3xl border border-[#1a1a1c] shadow-sm">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Status</p>
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                  <p className="text-[13px] font-bold text-white uppercase tracking-tighter">Active</p>
                </div>
              </div>
            </div>

            <h3 className="text-lg font-black text-white flex items-center gap-3">
              <i className={`fa-solid fa-bullhorn ${selectedHostel === 'Boys' ? 'text-indigo-400' : 'text-purple-400'}`}></i>
              {selectedHostel} Notice Board
            </h3>
            <div className="grid grid-cols-1 gap-4">
              {hostelNotifications.length > 0 ? (
                hostelNotifications.map(n => (
                  <NotificationCard key={n.id} notification={n} />
                ))
              ) : (
                <div className="py-20 text-center bg-[#0d0d0e] border border-dashed border-[#1a1a1c] rounded-[2.5rem] text-slate-600">
                  <p className="text-xs font-black uppercase tracking-widest">No signals broadcasted for this node.</p>
                </div>
              )}
            </div>

            <div className="bg-[#0d0d0e] p-8 rounded-[2.5rem] border border-[#1a1a1c] shadow-sm">
              <h3 className="font-black text-white mb-6 uppercase tracking-tight">Node Blocks & Amenities</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.3em] mb-4">Residential Units</p>
                  <div className="flex flex-wrap gap-2">
                    {currentDetails.blocks.map(block => (
                      <span key={block} className="px-4 py-2 bg-[#121214] border border-[#1f1f22] rounded-xl text-xs font-bold text-slate-400">
                        {block}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.3em] mb-4">Institutional Amenities</p>
                  <div className="flex flex-wrap gap-2">
                    {currentDetails.amenities.map(amenity => (
                      <span key={amenity} className={`px-4 py-2 bg-opacity-5 border border-opacity-20 rounded-xl text-xs font-bold ${selectedHostel === 'Boys' ? 'bg-indigo-400 border-indigo-400 text-indigo-400' : 'bg-purple-400 border-purple-400 text-purple-400'}`}>
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-[#0d0d0e] rounded-[2.5rem] p-8 border border-[#1a1a1c] shadow-xl">
              <h3 className="font-black text-white mb-6 flex items-center gap-3">
                <i className="fa-solid fa-utensils text-orange-500"></i>
                Operational Mess Menu
              </h3>
              <div className="space-y-5">
                <div className="flex justify-between items-center pb-4 border-b border-[#1a1a1c]">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Breakfast</span>
                  <span className="text-xs font-bold text-white">
                    {selectedHostel === 'Boys' ? 'Puri Bhaji & Coffee' : 'Idli, Vada & Tea'}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-[#1a1a1c]">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Lunch</span>
                  <span className="text-xs font-bold text-white">
                    {selectedHostel === 'Boys' ? 'North Indian Thali' : 'South Indian Special'}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-[#1a1a1c]">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Snacks</span>
                  <span className="text-xs font-bold text-white">Pakora / Biscuit</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Dinner</span>
                  <span className="text-xs font-bold text-white">Chapati & Curry</span>
                </div>
              </div>
              <button className="w-full mt-8 py-3 bg-[#121214] border border-[#1f1f22] text-slate-500 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:text-white transition-all flex items-center justify-center gap-2">
                <i className="fa-solid fa-download"></i> Full Weekly Logs
              </button>
            </div>

            <div className={`bg-gradient-to-br rounded-[2.5rem] p-8 text-white shadow-2xl ${selectedHostel === 'Boys' ? 'from-indigo-600 to-blue-700 shadow-indigo-600/10' : 'from-purple-600 to-indigo-700 shadow-purple-600/10'}`}>
              <h3 className="font-black text-xl mb-3 tracking-tight">Entry Protocol QR</h3>
              <p className="text-white/70 text-xs mb-8 leading-relaxed font-medium">Scan at the gate for automated biometric verification & entry logging.</p>
              <div className="bg-white p-6 rounded-3xl flex items-center justify-center aspect-square shadow-inner relative overflow-hidden group">
                 <i className={`fa-solid fa-qrcode text-7xl text-black opacity-10 transition-opacity group-hover:opacity-20`}></i>
                 <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-1 h-full bg-emerald-500/20 absolute left-1/2 -translate-x-1/2 animate-ping"></div>
                   <span className="bg-black text-emerald-500 text-[10px] font-black tracking-[0.4em] px-4 py-1.5 rounded-full border-2 border-emerald-500">SECURE_NODE</span>
                 </div>
              </div>
              <div className="mt-6 flex justify-between items-center text-[9px] font-black uppercase tracking-[0.2em] text-white/50">
                 <span>Token: {selectedHostel.toUpperCase()}-2024-X9</span>
                 <span className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
                    Valid
                 </span>
              </div>
            </div>

            <div className="bg-[#0d0d0e] rounded-[2.5rem] p-8 border border-[#1a1a1c] shadow-sm">
              <h3 className="font-black text-white mb-4 flex items-center gap-3 text-sm uppercase tracking-tight">
                <i className="fa-solid fa-screwdriver-wrench text-slate-600"></i>
                Maintenance Helpdesk
              </h3>
              <p className="text-[11px] text-slate-500 mb-6 leading-relaxed font-medium">
                Report infrastructure failures or utility outages to the estate management node instantly.
              </p>
              <button className={`w-full py-4 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl transition-all active:scale-95 ${selectedHostel === 'Boys' ? 'bg-indigo-600 shadow-indigo-500/10' : 'bg-purple-600 shadow-purple-500/10'}`}>
                Raise Signal Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HostelPage;
