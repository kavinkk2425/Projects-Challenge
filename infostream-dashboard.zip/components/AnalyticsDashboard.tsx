
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { Notification, Department } from '../types';

interface AnalyticsDashboardProps {
  notifications: Notification[];
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ notifications }) => {
  const isDark = document.documentElement.classList.contains('dark');

  // Category breakdown
  const categoryData = Object.values(notifications.reduce((acc, curr) => {
    acc[curr.category] = acc[curr.category] || { name: curr.category, value: 0 };
    acc[curr.category].value += 1;
    return acc;
  }, {} as any));

  // Department breakdown
  const deptData = Object.values(notifications.reduce((acc, curr) => {
    curr.targetDepartments.forEach(dept => {
      acc[dept] = acc[dept] || { name: dept, broadcasts: 0 };
      acc[dept].broadcasts += 1;
    });
    return acc;
  }, {} as any));

  const engagementData = notifications.map(n => ({
    title: n.title.substring(0, 15) + '...',
    reads: n.readCount,
    acks: n.acknowledgedBy.length * 10 
  })).slice(0, 5);

  const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f97316', '#eab308', '#22c55e'];
  const gridColor = isDark ? '#334155' : '#f1f5f9';
  const textColor = isDark ? '#94a3b8' : '#64748b';

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Total Broadcasts</p>
          <p className="text-3xl font-bold text-slate-900 dark:text-slate-100">{notifications.length}</p>
          <div className="mt-2 flex items-center text-emerald-600 dark:text-emerald-400 text-xs font-bold">
            <i className="fa-solid fa-arrow-trend-up mr-1"></i>
            <span>+12.5% vs last month</span>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Avg. Read Rate</p>
          <p className="text-3xl font-bold text-slate-900 dark:text-slate-100">84.2%</p>
          <div className="mt-2 flex items-center text-emerald-600 dark:text-emerald-400 text-xs font-bold">
            <i className="fa-solid fa-arrow-trend-up mr-1"></i>
            <span>+3.1% from baseline</span>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Critical Alerts</p>
          <p className="text-3xl font-bold text-red-600">3</p>
          <p className="mt-2 text-xs text-slate-400 dark:text-slate-500">Successfully acknowledged by 98%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">Volume by Category</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="transparent"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0', color: isDark ? '#f1f5f9' : '#1e293b' }}
                />
                <Legend layout="horizontal" verticalAlign="bottom" align="center" wrapperStyle={{ paddingTop: '20px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">Department-wise Activity</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deptData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke={gridColor} />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontWeight: 600, fill: textColor }} 
                  width={120}
                />
                <Tooltip 
                   cursor={{ fill: isDark ? '#334155' : '#f8fafc' }}
                   contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }}
                />
                <Bar dataKey="broadcasts" fill="#a855f7" radius={[0, 4, 4, 0]} barSize={24} name="Total Notifications" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-700 lg:col-span-2">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-6">Top Notification Engagement</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridColor} />
                <XAxis dataKey="title" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: textColor }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: textColor }} />
                <Tooltip 
                  cursor={{ fill: isDark ? '#334155' : '#f8fafc' }}
                  contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#fff', borderColor: isDark ? '#334155' : '#e2e8f0' }}
                />
                <Bar dataKey="reads" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={30} name="Total Reads" />
                <Bar dataKey="acks" fill="#f43f5e" radius={[4, 4, 0, 0]} barSize={30} name="Acknowledgements" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;
