
import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole: UserRole;
  isOpen?: boolean;
  onClose?: () => void;
  onLogout?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentTab, setCurrentTab, userRole, isOpen, onClose, onLogout }) => {
  const menuSections = [
    {
      title: 'PLATFORM',
      items: [
        { id: 'dashboard', icon: 'fa-grid-2', label: 'Overview' },
        { id: 'notifications', icon: 'fa-waveform-lines', label: 'Activity Feed', badge: '12' },
        { id: 'placement', icon: 'fa-briefcase-blank', label: 'Placement' },
      ]
    },
    {
      title: 'INSTITUTION',
      items: [
        { id: 'events', icon: 'fa-calendar-day', label: 'Campus Events' },
        { id: 'hostel', icon: 'fa-hotel', label: 'Residence' },
      ]
    },
    {
      title: 'MANAGEMENT',
      items: [
        ...(userRole === UserRole.ADMIN ? [{ id: 'compose', icon: 'fa-square-plus', label: 'Create New' }] : []),
        { id: 'analytics', icon: 'fa-chart-network', label: 'Insights' },
        { id: 'settings', icon: 'fa-gear', label: 'Preferences' },
      ]
    }
  ];

  return (
    <aside className={`
      fixed inset-y-0 left-0 z-50 w-[280px] bg-[#080809] border-r border-[#1a1a1c] 
      transform transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) md:translate-x-0 md:static md:h-screen
      flex flex-col
      ${isOpen ? 'translate-x-0 shadow-2xl shadow-black' : '-translate-x-full'}
    `}>
      <div className="h-20 px-8 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-[#10b981] w-9 h-9 rounded-xl flex items-center justify-center text-black shadow-[0_0_20px_rgba(16,185,129,0.2)]">
            <i className="fa-solid fa-satellite-dish text-lg font-black"></i>
          </div>
          <div className="flex flex-col">
            <h1 className="text-lg font-extrabold text-white leading-none tracking-tight">
              INFOSTREAM
            </h1>
            <span className="text-[9px] font-black text-[#10b981] tracking-[0.2em] uppercase mt-1">Nexus Intelligence</span>
          </div>
        </div>
        <button onClick={onClose} className="md:hidden text-slate-500 hover:text-white transition-colors">
          <i className="fa-solid fa-xmark text-lg"></i>
        </button>
      </div>

      <nav className="flex-1 px-4 py-10 overflow-y-auto custom-scrollbar space-y-12">
        {menuSections.map((section, idx) => (
          <div key={idx} className="space-y-2">
            <h2 className="px-4 text-[10px] font-black text-slate-600 uppercase tracking-[0.3em]">
              {section.title}
            </h2>
            <div className="space-y-1">
              {section.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`w-full flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all duration-300 group ${
                    currentTab === item.id
                      ? 'bg-[#121214] text-white border border-[#222225] shadow-lg shadow-black/40'
                      : 'text-slate-500 hover:text-white hover:bg-[#121214]/40'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${currentTab === item.id ? 'bg-[#10b981]/10 text-[#10b981]' : 'bg-[#121214] text-slate-600 group-hover:text-slate-300'}`}>
                      <i className={`fa-solid ${item.icon} text-sm`}></i>
                    </div>
                    <span className="text-[13px] font-bold tracking-tight">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {item.badge && (
                      <span className="bg-[#10b981] text-black text-[9px] font-black px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                    {currentTab === item.id && (
                      <div className="w-1 h-4 bg-[#10b981] rounded-full shadow-[0_0_12px_rgba(16,185,129,0.8)]"></div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-6 border-t border-[#1a1a1c]">
        <button 
          onClick={onLogout}
          className="w-full flex items-center justify-between px-6 py-4 bg-[#121214] border border-[#1a1a1c] rounded-2xl text-red-500 hover:bg-red-500/5 hover:border-red-500/20 transition-all group active:scale-95"
        >
          <span className="text-xs font-black uppercase tracking-widest">Sign Out</span>
          <i className="fa-solid fa-arrow-right-from-bracket text-xs group-hover:translate-x-1 transition-transform"></i>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
