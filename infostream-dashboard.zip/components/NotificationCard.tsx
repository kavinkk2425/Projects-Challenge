
import React from 'react';
import { Notification, Priority, NotificationCategory } from '../types';

interface NotificationCardProps {
  notification: Notification;
  onAcknowledge?: (id: string) => void;
  hasAcknowledged?: boolean;
}

const NotificationCard: React.FC<NotificationCardProps> = ({ 
  notification, 
  onAcknowledge,
  hasAcknowledged 
}) => {
  const getCategoryTheme = (cat: NotificationCategory) => {
    switch (cat) {
      case NotificationCategory.EMERGENCY: return { icon: 'fa-diamond-exclamation', color: 'text-red-500', bg: 'bg-red-500/10', border: 'border-red-500/10' };
      case NotificationCategory.PLACEMENT: return { icon: 'fa-briefcase', color: 'text-[#10b981]', bg: 'bg-[#10b981]/10', border: 'border-[#10b981]/10' };
      case NotificationCategory.EXAM: return { icon: 'fa-file-signature', color: 'text-[#facc15]', bg: 'bg-[#facc15]/10', border: 'border-[#facc15]/10' };
      case NotificationCategory.HOSTEL: return { icon: 'fa-hotel', color: 'text-cyan-400', bg: 'bg-cyan-400/10', border: 'border-cyan-400/10' };
      case NotificationCategory.EVENTS: return { icon: 'fa-calendar-star', color: 'text-purple-400', bg: 'bg-purple-400/10', border: 'border-purple-400/10' };
      default: return { icon: 'fa-circle-info', color: 'text-indigo-400', bg: 'bg-indigo-400/10', border: 'border-indigo-400/10' };
    }
  };

  const theme = getCategoryTheme(notification.category);

  return (
    <div className="group grid grid-cols-1 md:grid-cols-[1fr_120px_120px_auto] items-center p-3 md:p-4 bg-[#0d0d0e] border border-[#1a1a1c] rounded-2xl hover:bg-[#121214] hover:border-[#222225] transition-all duration-300 gap-4">
      
      {/* 1. Main Info Column */}
      <div className="flex items-center gap-5 pl-2 overflow-hidden">
        <div className={`w-12 h-12 rounded-[18px] ${theme.bg} border ${theme.border} flex items-center justify-center ${theme.color} shrink-0 shadow-inner group-hover:scale-105 transition-transform duration-500`}>
          <i className={`fa-solid ${theme.icon} text-lg`}></i>
        </div>
        <div className="overflow-hidden py-1">
          <h4 className="text-[15px] font-bold text-white tracking-tight group-hover:text-white transition-colors truncate">
            {notification.title}
          </h4>
          <div className="flex items-center gap-2.5 mt-1 text-[10px] font-black uppercase tracking-[0.15em] text-slate-500">
            <span className="truncate opacity-70">{notification.sender}</span>
            <div className="w-1 h-1 bg-slate-800 rounded-full"></div>
            <span className={theme.color}>{notification.category}</span>
          </div>
        </div>
      </div>

      {/* 2. Timeline Column */}
      <div className="hidden md:flex flex-col items-center justify-center border-l border-[#1a1a1c] h-10">
        <p className="text-[13px] font-extrabold text-white tracking-tight leading-none">
          {new Date(notification.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
        </p>
        <p className="text-[9px] text-slate-600 font-black uppercase tracking-[0.2em] mt-2">TIMELINE</p>
      </div>

      {/* 3. Reach & Priority Column */}
      <div className="hidden md:flex flex-col items-center justify-center border-l border-[#1a1a1c] h-10">
        <p className="text-[13px] font-extrabold text-white tracking-tight leading-none whitespace-nowrap">
          Reach {notification.readCount.toLocaleString()}
        </p>
        <p className={`text-[9px] font-black uppercase tracking-[0.2em] mt-2 ${
          notification.priority === Priority.CRITICAL ? 'text-red-500' : 
          notification.priority === Priority.HIGH ? 'text-[#facc15]' : 
          notification.priority === Priority.MEDIUM ? 'text-slate-500' : 'text-slate-700'
        }`}>
          {notification.priority}
        </p>
      </div>

      {/* 4. Action Column */}
      <div className="flex items-center justify-end md:pl-6">
        {onAcknowledge ? (
          <button
            disabled={hasAcknowledged}
            onClick={() => onAcknowledge(notification.id)}
            className={`h-11 px-6 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300 ${
              hasAcknowledged 
                ? 'bg-transparent border border-[#1a1a1c] text-slate-700 cursor-not-allowed'
                : 'bg-white text-black hover:bg-slate-200 shadow-xl shadow-white/5 active:scale-95'
            }`}
          >
            {hasAcknowledged ? 'Confirmed' : 'Resolve'}
          </button>
        ) : (
          <div className="w-11 h-11 rounded-2xl bg-[#121214] border border-[#1f1f22] flex items-center justify-center text-slate-600 group-hover:text-white transition-colors cursor-pointer">
             <i className="fa-solid fa-chevron-right text-xs"></i>
          </div>
        )}
      </div>

      {/* Mobile Responsive Details (Visible only on small screens) */}
      <div className="md:hidden flex items-center justify-between pt-2 border-t border-[#1a1a1c] mt-2">
        <div className="flex flex-col">
          <span className="text-[9px] text-slate-600 font-black uppercase tracking-widest">TIMELINE</span>
          <span className="text-[11px] font-bold text-white">{new Date(notification.timestamp).toLocaleDateString()}</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[9px] text-slate-600 font-black uppercase tracking-widest">REACH</span>
          <span className="text-[11px] font-bold text-white">{notification.readCount.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

export default NotificationCard;
