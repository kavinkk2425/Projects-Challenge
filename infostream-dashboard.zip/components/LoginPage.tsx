
import React, { useState } from 'react';
import { User, UserRole, Department } from '../types';
import { CURRENT_USER } from '../constants';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [loginType, setLoginType] = useState<UserRole>(UserRole.STUDENT);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Mock authentication logic
    setTimeout(() => {
      const normalizedUser = username.toLowerCase();
      
      if (loginType === UserRole.ADMIN && normalizedUser !== 'admin') {
        setError('Unauthorized access. Admin credentials required.');
        setIsLoading(false);
        return;
      }

      if (normalizedUser === 'kavin' || normalizedUser === 'admin') {
        const userToLogin: User = { 
          ...CURRENT_USER, 
          id: normalizedUser === 'admin' ? 'admin_001' : 'user_001',
          name: normalizedUser === 'admin' ? 'System Administrator' : 'Kavin',
          role: loginType,
          avatar: normalizedUser === 'admin' 
            ? 'https://api.dicebear.com/7.x/bottts/svg?seed=Admin' 
            : 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kavin'
        };
        onLogin(userToLogin);
      } else {
        setError('Credential mismatch. Try "kavin" for student or "admin" for admin.');
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-6 overflow-hidden bg-[#050505]">
      {/* Dynamic Background Accents */}
      <div className={`absolute top-[-15%] left-[-15%] w-[60%] h-[60%] rounded-full blur-[140px] pointer-events-none transition-all duration-1000 ${loginType === UserRole.ADMIN ? 'bg-indigo-600/20' : 'bg-[#10b981]/10'}`}></div>
      <div className={`absolute bottom-[-15%] right-[-15%] w-[60%] h-[60%] rounded-full blur-[140px] pointer-events-none transition-all duration-1000 ${loginType === UserRole.ADMIN ? 'bg-purple-600/20' : 'bg-cyan-500/10'}`}></div>

      <div className="w-full max-w-md relative z-10 animate-in fade-in zoom-in-95 duration-700">
        <div className="bg-[#0a0a0b]/80 backdrop-blur-3xl rounded-[3rem] shadow-[0_40px_80px_-15px_rgba(0,0,0,0.8)] border border-white/5 p-10 md:p-14">
          <div className="text-center mb-10">
            <div className={`inline-flex items-center justify-center w-20 h-20 rounded-3xl text-black shadow-2xl transition-all duration-500 mb-6 ${loginType === UserRole.ADMIN ? 'bg-indigo-500 shadow-indigo-500/40 rotate-12' : 'bg-[#10b981] shadow-[#10b981]/40'}`}>
              <i className={`fa-solid ${loginType === UserRole.ADMIN ? 'fa-satellite-dish' : 'fa-tower-broadcast'} text-3xl`}></i>
            </div>
            <h1 className="text-3xl font-black text-white mb-2 tracking-tighter uppercase">
              InfoStream Gateway
            </h1>
            <p className="text-slate-500 font-black text-[10px] uppercase tracking-[0.4em] opacity-60">
              Institutional Intelligence
            </p>
          </div>

          {/* User Type Switcher */}
          <div className="flex bg-[#0d0d0e] p-1.5 rounded-2xl border border-[#1f1f22] mb-10 relative overflow-hidden">
            <button 
              type="button"
              onClick={() => setLoginType(UserRole.STUDENT)}
              className={`flex-1 py-3 px-4 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all duration-300 flex items-center justify-center gap-2 z-10 ${loginType === UserRole.STUDENT ? 'bg-[#10b981] text-black shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <i className="fa-solid fa-user-graduate"></i>
              Student
            </button>
            <button 
              type="button"
              onClick={() => setLoginType(UserRole.ADMIN)}
              className={`flex-1 py-3 px-4 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all duration-300 flex items-center justify-center gap-2 z-10 ${loginType === UserRole.ADMIN ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <i className="fa-solid fa-user-shield"></i>
              Admin
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] ml-1">Identity Identifier</label>
              <div className="relative group">
                <i className={`fa-solid fa-fingerprint absolute left-5 top-1/2 -translate-y-1/2 transition-colors ${loginType === UserRole.ADMIN ? 'text-indigo-400' : 'text-[#10b981]'}`}></i>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={loginType === UserRole.ADMIN ? "Enter 'admin'" : "Enter 'kavin'"}
                  className="w-full pl-14 pr-6 py-4 bg-[#0d0d0e] border border-[#1f1f22] focus:border-white/20 rounded-[1.25rem] text-white placeholder:text-slate-800 outline-none transition-all font-bold text-sm"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] ml-1">Access Protocol</label>
              <div className="relative group">
                <i className="fa-solid fa-key-skeleton absolute left-5 top-1/2 -translate-y-1/2 text-slate-700 group-focus-within:text-white transition-colors"></i>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-14 pr-6 py-4 bg-[#0d0d0e] border border-[#1f1f22] focus:border-white/20 rounded-[1.25rem] text-white placeholder:text-slate-800 outline-none transition-all font-bold text-sm"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-500/5 border border-red-500/20 text-red-500 text-[11px] font-bold p-4 rounded-2xl flex items-center gap-3 animate-pulse">
                <i className="fa-solid fa-triangle-exclamation text-base"></i>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-4 rounded-[1.25rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl transition-all flex items-center justify-center gap-3 disabled:opacity-50 active:scale-[0.98] mt-4 ${
                loginType === UserRole.ADMIN 
                ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-500/20' 
                : 'bg-white hover:bg-slate-200 text-black shadow-white/5'
              }`}
            >
              {isLoading ? (
                <i className="fa-solid fa-dna fa-spin text-lg"></i>
              ) : (
                <>
                  Establish Connection
                  <i className="fa-solid fa-arrow-right text-[10px]"></i>
                </>
              )}
            </button>
          </form>

          <div className="mt-12 flex flex-col items-center gap-4">
             <div className="flex items-center gap-6">
                <span className="text-[9px] text-slate-700 font-black uppercase tracking-[0.2em] flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
                  Nodes Verified
                </span>
                <span className="text-[9px] text-slate-700 font-black uppercase tracking-[0.2em] flex items-center gap-2">
                  <i className="fa-solid fa-shield-check text-[10px]"></i>
                  AES-256 Active
                </span>
             </div>
             <p className="text-[8px] text-slate-800 font-black uppercase tracking-widest text-center">
                Unauthorized access to institutional nodes is strictly monitored.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
