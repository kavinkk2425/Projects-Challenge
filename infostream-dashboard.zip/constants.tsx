
import React from 'react';
import { 
  NotificationCategory, 
  Priority, 
  UserRole, 
  Department, 
  TargetYear,
  Notification, 
  User 
} from './types';

export const CURRENT_USER: User = {
  id: 'user_001',
  name: 'Kavin',
  role: UserRole.ADMIN,
  department: Department.COMPUTER_SCIENCE,
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kavin'
};

export interface FacultyMember {
  id: string;
  name: string;
  role: 'HOD' | 'Advisor';
  dept: Department;
  year?: TargetYear;
  email: string;
  avatar: string;
}

export const MOCK_FACULTY: FacultyMember[] = [
  { id: 'f1', name: 'Dr. Sarah Wilson', role: 'HOD', dept: Department.COMPUTER_SCIENCE, email: 's.wilson@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah' },
  { id: 'f2', name: 'Dr. James Chen', role: 'HOD', dept: Department.MECHANICAL, email: 'j.chen@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=James' },
  { id: 'f3', name: 'Prof. Michael Ross', role: 'Advisor', dept: Department.COMPUTER_SCIENCE, year: TargetYear.FIRST, email: 'm.ross@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael' },
  { id: 'f4', name: 'Prof. Rachel Zane', role: 'Advisor', dept: Department.COMPUTER_SCIENCE, year: TargetYear.SECOND, email: 'r.zane@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rachel' },
  { id: 'f5', name: 'Dr. Robert Specter', role: 'Advisor', dept: Department.COMPUTER_SCIENCE, year: TargetYear.THIRD, email: 'r.specter@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Robert' },
  { id: 'f6', name: 'Prof. Donna Paulsen', role: 'Advisor', dept: Department.COMPUTER_SCIENCE, year: TargetYear.FOURTH, email: 'd.paulsen@infostream.edu', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Donna' },
];

export interface CampusEvent {
  id: string;
  title: string;
  type: 'Symposium' | 'Hackathon' | 'Coding Contest' | 'Workshop';
  date: string;
  venue: string;
  description: string;
  prizePool?: string;
  coordinator: string;
  image: string;
  departments: Department[];
}

export interface CompanyPlacement {
  id: string;
  name: string;
  logo: string;
  role: string;
  ctc: string;
  deadline: string;
  status: 'Open' | 'Closed' | 'Ongoing';
}

export const MOCK_COMPANIES: CompanyPlacement[] = [
  {
    id: 'c1',
    name: 'Google',
    logo: 'https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png',
    role: 'Software Engineer',
    ctc: '32 LPA',
    deadline: 'Oct 15, 2024',
    status: 'Open'
  },
  {
    id: 'c2',
    name: 'Microsoft',
    logo: 'https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageMedia/RE1Mu3b?ver=5ad4',
    role: 'SDE Intern',
    ctc: '15 LPA',
    deadline: 'Oct 20, 2024',
    status: 'Open'
  },
  {
    id: 'c3',
    name: 'Amazon',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg',
    role: 'Cloud Support Engineer',
    ctc: '18 LPA',
    deadline: 'Oct 10, 2024',
    status: 'Ongoing'
  },
  {
    id: 'c4',
    name: 'TCS',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/b/b1/Tata_Consultancy_Services_Logo.svg',
    role: 'System Engineer',
    ctc: '7 LPA',
    deadline: 'Oct 05, 2024',
    status: 'Closed'
  }
];

export const MOCK_EVENTS: CampusEvent[] = [
  {
    id: 'ev_1',
    title: 'Nexus Symposium 2024',
    type: 'Symposium',
    date: 'March 15, 2024',
    venue: 'Main Auditorium',
    description: 'A national level technical symposium featuring paper presentations, project expos, and guest lectures from industry experts.',
    coordinator: 'Prof. Anjali Sharma',
    image: 'https://images.unsplash.com/photo-1540575861501-7cf05a4b125a?auto=format&fit=crop&w=800&q=80',
    departments: [Department.ALL]
  },
  {
    id: 'ev_2',
    title: 'GCE Code-A-Thon v2.0',
    type: 'Coding Contest',
    date: 'April 05, 2024',
    venue: 'Computer Center (Block B)',
    description: '12-hour intensive coding challenge to solve real-world algorithmic problems. Open to all students.',
    prizePool: '₹50,000',
    coordinator: 'Dr. Rajesh Kumar',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
    departments: [Department.COMPUTER_SCIENCE, Department.ELECTRICAL]
  },
  {
    id: 'ev_3',
    title: 'InnoHack 2024',
    type: 'Hackathon',
    date: 'May 12-14, 2024',
    venue: 'Innovation Hub',
    description: '3-day product development hackathon focused on sustainable campus solutions. Build, pitch, and win.',
    prizePool: '₹1,00,000',
    coordinator: 'Tech Council',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
    departments: [Department.ALL]
  }
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    title: 'Emergency: Severe Weather Warning',
    message: 'Campus will be closing at 2:00 PM today due to incoming severe thunderstorms. Please clear all outdoor areas.',
    category: NotificationCategory.EMERGENCY,
    priority: Priority.CRITICAL,
    sender: 'Campus Safety',
    timestamp: new Date().toISOString(),
    targetRoles: [UserRole.STUDENT, UserRole.FACULTY, UserRole.ADMIN],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 1450,
    acknowledgedBy: ['user_001']
  },
  {
    id: 'h1',
    title: 'Boys Hostel: Biometric System Offline',
    message: 'The biometric entry system for the Boys Main Hostel is temporarily offline for maintenance. Please use manual entry register.',
    category: NotificationCategory.HOSTEL,
    priority: Priority.MEDIUM,
    sender: 'Warden Office',
    timestamp: new Date().toISOString(),
    targetRoles: [UserRole.STUDENT],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 310,
    acknowledgedBy: []
  },
  {
    id: 'h2',
    title: 'Girls Hostel: Cultural Night Registrations',
    message: 'Registrations are open for the annual hostel cultural night. Interested students can register at the common room desk.',
    category: NotificationCategory.HOSTEL,
    priority: Priority.LOW,
    sender: 'Cultural Coordinator',
    timestamp: new Date().toISOString(),
    targetRoles: [UserRole.STUDENT],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 240,
    acknowledgedBy: []
  },
  {
    id: '4',
    title: 'Hostel: Mess Menu Update',
    message: 'The Revised Mess Menu for March 2024 has been uploaded. Special dinner scheduled for upcoming festival on Friday.',
    category: NotificationCategory.HOSTEL,
    priority: Priority.MEDIUM,
    sender: 'Chief Warden',
    timestamp: new Date().toISOString(),
    targetRoles: [UserRole.STUDENT],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 520,
    acknowledgedBy: []
  },
  {
    id: '2',
    title: 'Final Exam Schedule Published',
    message: 'The schedule for the Spring 2024 final examinations is now available on the student portal.',
    category: NotificationCategory.EXAM,
    priority: Priority.HIGH,
    sender: 'Registrar Office',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    targetRoles: [UserRole.STUDENT, UserRole.FACULTY],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 890,
    acknowledgedBy: []
  },
  {
    id: '5',
    title: 'Hostel Maintenance: Water Tank Cleaning',
    message: 'Water supply to Blocks A and B will be suspended from 10:00 AM to 4:00 PM tomorrow for periodic tank maintenance.',
    category: NotificationCategory.HOSTEL,
    priority: Priority.HIGH,
    sender: 'Estate Management',
    timestamp: new Date(Date.now() - 14400000).toISOString(),
    targetRoles: [UserRole.STUDENT],
    targetDepartments: [Department.ALL],
    targetYears: [TargetYear.ALL],
    readCount: 740,
    acknowledgedBy: []
  },
  {
    id: '3',
    title: 'Google Placement Drive',
    message: 'Google is conducting a campus recruitment drive for Software Engineering roles. Registration closes Friday.',
    category: NotificationCategory.PLACEMENT,
    priority: Priority.HIGH,
    sender: 'Placement Cell',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    targetRoles: [UserRole.STUDENT],
    targetDepartments: [Department.COMPUTER_SCIENCE, Department.ELECTRICAL],
    targetYears: [TargetYear.FOURTH, TargetYear.THIRD],
    readCount: 420,
    acknowledgedBy: []
  }
];

export const CATEGORY_COLORS: Record<NotificationCategory, string> = {
  [NotificationCategory.ACADEMIC]: 'bg-blue-100 text-blue-700 border-blue-200',
  [NotificationCategory.ADMINISTRATIVE]: 'bg-slate-100 text-slate-700 border-slate-200',
  [NotificationCategory.PLACEMENT]: 'bg-purple-100 text-purple-700 border-purple-200',
  [NotificationCategory.EXAM]: 'bg-amber-100 text-amber-700 border-amber-200',
  [NotificationCategory.EVENTS]: 'bg-green-100 text-green-700 border-green-200',
  [NotificationCategory.EMERGENCY]: 'bg-red-100 text-red-700 border-red-200',
  [NotificationCategory.HOSTEL]: 'bg-cyan-100 text-cyan-700 border-cyan-200'
};

export const PRIORITY_COLORS: Record<Priority, string> = {
  [Priority.CRITICAL]: 'text-red-600 font-bold uppercase animate-pulse',
  [Priority.HIGH]: 'text-orange-600 font-semibold',
  [Priority.MEDIUM]: 'text-blue-600',
  [Priority.LOW]: 'text-slate-500'
};
